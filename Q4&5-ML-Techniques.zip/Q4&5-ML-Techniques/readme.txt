1. Ensure that eval.csv and train.csv are in the same folder.

2. To run the jupyter notebooks for the first time, uncomment the cells with pip installs to install the required libraries.

